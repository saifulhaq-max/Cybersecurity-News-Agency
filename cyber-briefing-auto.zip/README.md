# Signal — Auto-Updating Cyber Briefing (free, no API keys)

A dashboard that rebuilds itself every day by pulling from six public
cybersecurity RSS feeds (The Hacker News, BleepingComputer, Krebs on
Security, Dark Reading, SecurityWeek, CISA advisories), sorting stories
into Attacks & Breaches / Vulnerabilities & Tools / Policy & Regulation,
and republishing as a free website. No AI rewriting — real headlines and
publisher summaries, auto-refreshed daily at zero cost.

## One-time setup (about 10 minutes)

1. **Create a GitHub account** if you don't have one: https://github.com/signup (free)

2. **Create a new repository**
   - Go to https://github.com/new
   - Name it anything, e.g. `cyber-briefing`
   - Set it to **Public** (required for free GitHub Pages)
   - Don't add a README/gitignore — leave it empty
   - Click "Create repository"

3. **Upload these files**
   - On your new repo's page, click "uploading an existing file"
   - Drag in everything from this folder, **keeping the folder structure**
     (the `.github/workflows/daily-build.yml` file must stay inside
     `.github/workflows/`)
   - Commit the files

4. **Allow the workflow to push updates**
   - Go to your repo's **Settings → Actions → General**
   - Scroll to "Workflow permissions"
   - Select **"Read and write permissions"**
   - Click Save

5. **Turn on GitHub Pages**
   - Go to **Settings → Pages**
   - Under "Build and deployment," set Source to **"Deploy from a branch"**
   - Branch: **main**, folder: **/ (root)**
   - Click Save
   - GitHub will give you a URL like `https://yourusername.github.io/cyber-briefing/`
     — bookmark that. It may take a minute or two to go live the first time.

6. **Run it once manually to generate the first edition**
   - Go to the **Actions** tab in your repo
   - Click "Daily Cyber Briefing Build" on the left
   - Click "Run workflow" → "Run workflow"
   - Wait ~30 seconds, then refresh your GitHub Pages URL

That's it. From now on, GitHub's own servers run this automatically every
day at 07:00 UTC — your phone, laptop, everything can be off and it still
updates. Just open the bookmarked URL any time to see the latest edition.

## Customizing

- **Change the time it updates:** edit the `cron: "0 7 * * *"` line in
  `.github/workflows/daily-build.yml` (format: minute hour day month
  weekday, all in UTC).
- **Add or remove sources:** edit the `FEEDS` list at the top of
  `fetch_and_build.py`.
- **Change how stories get categorized:** edit the `POLICY_KEYWORDS`,
  `VULN_KEYWORDS`, and `ATTACK_KEYWORDS` lists in `fetch_and_build.py`.
- **Change how many stories per section:** edit `MAX_PER_CATEGORY`.

## Cost

$0. GitHub Actions gives free accounts 2,000 build-minutes/month — this
job takes under a minute a day, so you'll use roughly 30 minutes/month.
GitHub Pages hosting for public repos is free with no limit that matters
here.
